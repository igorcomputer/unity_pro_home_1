using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Assets.Scripts.GameSystem
{
    public class MoveController : MonoBehaviour, IGameStartListener, IGameFinishListener
    {
        [SerializeField]
        private Player player;

        [SerializeField]
        private KeyboardInput inputKeyboard;

        [SerializeField]
        private MoveInput inputMove;

        private float gutterWidth = 3f;
        private int[] roads = new int[] { 0, 1, 2 };

        private int _roadIndex = 1;

        void IGameStartListener.OnStartGame()
        {
            //Debug.Log("MoveController: START GAME"); 
            this.inputMove.onMove += this.onMove; 
            this.inputKeyboard.onSideMove += this.onSideMove; 
        }

        void IGameFinishListener.OnFinishGame()
        {
            //Debug.Log("MoveController: Finish GAME"); 
            this.inputMove.onMove += this.onMove; 
            this.inputKeyboard.onSideMove -= this.onSideMove; 
        }

        private void onSideMove(Vector2 direction)
        {
            this.SideMove(direction);
        }

        private void onMove()
        {
            var offset = Vector3.forward * Time.deltaTime; 
            this.player.Move(offset); 
        }

        private void SideMove(Vector2 direction)
        {
            
            if (direction == Vector2.left && CanSideMove())
                _roadIndex--; 
            
            if (direction == Vector2.right && CanSideMove())
                _roadIndex++; 

            var playerPosition = this.player.GetPosition();
            var targetPosition = new Vector3();
            targetPosition.y = playerPosition.y;
            targetPosition.z = playerPosition.z;
            targetPosition.x += _roadIndex * gutterWidth;
            player.SetPosition(targetPosition);

        }

        private bool CanSideMove()
        {
            bool result = false;
            if (_roadIndex > 0)
                result = true;

            if (_roadIndex < roads.Length - 1)
                result = true;
            
            return result;
        }


    }

}