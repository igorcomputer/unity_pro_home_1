using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using System;

namespace Assets.Scripts.GameSystem
{

    public sealed class KeyboardInput : MonoBehaviour, 
        IGameStartListener, 
        IGameFinishListener,
        IGamePauseListener,
        IGameResumeListener
    {
        public Action<Vector2> onSideMove;

        private void Awake() 
        {
            this.enabled = false;
        }

        private void Update()
        {
            Debug.Log("Update");  
            HandleKeyboard(); 
        }

        private void HandleKeyboard()
        {
            if (Input.GetKeyDown(KeyCode.LeftArrow))
            {
                Debug.Log("LeftArrow");  
                this.SideMove(Vector2.left);  
            }

            if (Input.GetKeyDown(KeyCode.RightArrow))
            {
                Debug.Log("RightArrow"); 
                this.SideMove(Vector2.right); 
            }
        } 

        private void SideMove(Vector2 direction)
        {
            this.onSideMove?.Invoke(direction); 
        }
        void IGameStartListener.OnStartGame()
        {
            Debug.Log("// keyboardInput - START GAME");  
            this.enabled = true;
        }
        void IGameFinishListener.OnFinishGame()
        {
            Debug.Log("// keyboardInput - FINISH GAME"); 
            this.enabled = false;
        } 
        void IGamePauseListener.OnPauseGame()
        {
            this.enabled = false;
        }
        void IGameResumeListener.OnResumeGame()
        {
            this.enabled = true;
        }

    }

}



