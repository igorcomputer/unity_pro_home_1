using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using System;

namespace Assets.Scripts.GameSystem
{

    public class MoveInput : MonoBehaviour,
        IGameStartListener,
        IGameFinishListener,
        IGamePauseListener,
        IGameResumeListener
    {
        public Action onMove;


        void Awake()
        {
            this.enabled = false;  
        }

        void Update()
        {
             this.Move();  
        }

        private void Move()
        {
            this.onMove.Invoke();
        }
        void IGameStartListener.OnStartGame()
        {
            this.enabled = true;
        }

        void IGameFinishListener.OnFinishGame()
        {
            this.enabled = false;
        }

        void IGameResumeListener.OnResumeGame()
        {
            this.enabled = true;
        }

        void IGamePauseListener.OnPauseGame()
        {
            this.enabled = false;
        }


    }

}
